let topicsData = {};
let currentTopic = "";

/***********************************************************
 * INITIAL LOAD
 ***********************************************************/
document.addEventListener("DOMContentLoaded", () => {
    loadTopics();
    setupBackButtons();
});

/***********************************************************
 * LOAD TOPICS
 ***********************************************************/
function loadTopics() {
    fetch("/api/topics")
        .then(res => res.json())
        .then(data => {
            topicsData = data;
            displayTopics();
        });
}

function displayTopics() {
    const grid = document.getElementById("topicsGrid");
    grid.innerHTML = "";

    Object.keys(topicsData).forEach(key => {
        if (key === "quizzes") return;

        const t = topicsData[key];
        const card = document.createElement("div");
        card.className = "topic-card";

        card.innerHTML = `
            <div class="topic-card-header">
                <div class="topic-icon">📘</div>
                <h3>${t.title}</h3>
            </div>
            <p>${t.description}</p>
        `;

        card.onclick = () => openTopic(key);
        grid.appendChild(card);
    });
}

/***********************************************************
 * OPEN TOPIC
 ***********************************************************/
function openTopic(topicName) {
    currentTopic = topicName;

    document.getElementById("homePage").classList.remove("active");
    document.getElementById("detailPage").classList.add("active");

    const topic = topicsData[topicName];

    // Header
    document.getElementById("topicHeader").innerHTML = `
        <h1>${topic.title}</h1>
        <p>${topic.description}</p>
    `;

    // Subtopics
    const subWrap = document.getElementById("subtopicsContainer");
    subWrap.innerHTML = "";

    topic.types.forEach(st => {
        const box = document.createElement("div");
        box.className = "subtopic-card";

        box.innerHTML = `
            <div class="subtopic-header">
                <h2>${st.name}</h2>
                <p>${st.description}</p>
            </div>

            <div class="subtopic-content">
                <div class="content-section"><h3>Pseudocode</h3><pre>${st.pseudocode}</pre></div>
                <div class="content-section"><h3>Code</h3><pre>${st.code}</pre></div>
                <div class="content-section"><h3>Example</h3><pre>${st.example}</pre></div>
                <div class="content-section"><h3>Complexity</h3><p>${st.complexity}</p></div>
            </div>
        `;

        box.querySelector(".subtopic-header").onclick = () => {
            box.classList.toggle("active");
        };

        subWrap.appendChild(box);
    });

    loadComments(topicName);
    renderQuizButton();
}

/***********************************************************
 * QUIZ BUTTON
 ***********************************************************/
function renderQuizButton() {
    const qWrap = document.getElementById("quizContainer");
    qWrap.innerHTML = `
        <button id="startQuizBtn" class="quiz-btn">Start Quiz</button>
    `;

    document.getElementById("startQuizBtn").onclick = () => startQuiz();
}

function startQuiz() {
    fetch(`/api/quiz/${currentTopic}`)
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                alert("No quiz available");
                return;
            }
            showQuiz(data);
        });
}

/***********************************************************
 * SHOW QUIZ
 ***********************************************************/
function showQuiz(data) {
    document.getElementById("detailPage").classList.remove("active");
    document.getElementById("quizPage").classList.add("active");

    document.getElementById("quizTitle").innerText = data.title;

    const quizInner = document.getElementById("quizInner");
    quizInner.innerHTML = "";

    data.questions.forEach((q, i) => {
        const box = document.createElement("div");
        box.className = "quiz-box";

        let opts = "";
        for (let key in q.options) {
            opts += `
                <label class="quiz-option">
                    <input type="radio" name="q${i}" value="${key}">
                    <b>${key}:</b> ${q.options[key]}
                </label>
            `;
        }

        box.innerHTML = `
            <h3>Q${i + 1}. ${q.q}</h3>
            ${opts}
            <p id="result_${i}" style="margin-top:10px;"></p>
        `;

        box.querySelectorAll("input").forEach(r => {
            r.onchange = () => showAnswer(i, q.answer, q.explanation);
        });

        quizInner.appendChild(box);
    });
}

function showAnswer(i, ans, exp) {
    const r = document.getElementById(`result_${i}`);
    r.innerHTML = `✅ Correct answer: <b>${ans}</b><br>${exp}`;
    r.style.color = "lightgreen";
}

/***********************************************************
 * COMMENTS
 ***********************************************************/
function loadComments(topic) {
    fetch(`/api/comments/${topic}`)
        .then(r => r.json())
        .then(data => renderComments(data));

    document.getElementById("postCommentBtn").onclick = postComment;
}

function renderComments(list) {
    const container = document.getElementById("commentsList");
    container.innerHTML = "";

    list.forEach(c => {
        container.innerHTML += `
            <div style="background:#222;padding:12px;border-radius:8px;margin-top:10px;">
                <b>${c.name}</b> <small>${c.time}</small><br>
                ${c.text}
            </div>
        `;
    });
}

function postComment() {
    const name = document.getElementById("commentName").value.trim();
    const text = document.getElementById("commentText").value.trim();

    if (text === "") {
        alert("Write a comment.");
        return;
    }

    fetch(`/api/comments/${currentTopic}`, {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ name, text })
    })
        .then(r => r.json())
        .then(() => {
            loadComments(currentTopic);
            document.getElementById("commentText").value = "";
        });
}

/***********************************************************
 * BACK BUTTONS
 ***********************************************************/
function setupBackButtons() {
    document.getElementById("backBtn").onclick = () => {
        document.getElementById("detailPage").classList.remove("active");
        document.getElementById("homePage").classList.add("active");
    };

    document.getElementById("backToTopic").onclick = () => {
        document.getElementById("quizPage").classList.remove("active");
        document.getElementById("detailPage").classList.add("active");
    };
}
