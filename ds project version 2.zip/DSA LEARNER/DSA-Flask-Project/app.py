from flask import Flask, render_template, jsonify, request
from datetime import datetime

app = Flask(__name__)

# ===================== COMMENT STORAGE =====================
comments_data = {
    "sorting": [],
    "searching": [],
    "hashing": [],
    "arrays": [],
    "linkedlist": [],
    "stack": [],
    "queue": [],
    "tree": []
}

# ===================== DSA DATA (TOPICS + QUIZZES) =====================

dsa_data = {

    # ------------ ARRAYS ------------
    "arrays": {
        "title": "Arrays",
        "description": "Sequential collection of elements stored in contiguous memory locations",
        "types": [
            {
                "name": "1D Array",
                "description": "Linear array with single dimension",
                "pseudocode": "Traverse array from index 0 to n-1",
                "code": """#include <iostream>
using namespace std;
int main() {
    int arr[5]={10,20,30,40,50};
    for(int i=0;i<5;i++) cout<<arr[i]<<" ";
    return 0;
}""",
                "example": "10 20 30 40 50",
                "complexity": "O(n)"
            },
            {
                "name": "2D Array",
                "description": "Matrix representation",
                "pseudocode": "Double loop over rows and columns",
                "code": """#include <iostream>
using namespace std;
int main(){
 int a[2][3]={{1,2,3},{4,5,6}};
 for(int i=0;i<2;i++){
   for(int j=0;j<3;j++) cout<<a[i][j]<<" ";
   cout<<endl;
 }
}""",
                "example": "Matrix printed row-wise",
                "complexity": "O(r*c)"
            }
        ]
    },

    # ------------ LINKED LIST ------------
    "linkedlist": {
        "title": "Linked List",
        "description": "Nodes connected by pointers",
        "types": [
            {
                "name": "Singly Linked List",
                "description": "Each node points to next node",
                "pseudocode": "Insert new node at head",
                "code": """#include <iostream>
using namespace std;
struct Node{int data; Node*next; Node(int x):data(x),next(NULL){}};
int main(){Node*h=new Node(10); cout<<"10->NULL";}""",
                "example": "10 -> NULL",
                "complexity": "O(1)"
            }
        ]
    },

    # ------------ STACK ------------
    "stack": {
        "title": "Stack",
        "description": "LIFO structure",
        "types": [
            {
                "name": "Array Stack",
                "description": "Uses array",
                "pseudocode": "Push/Pop operations",
                "code": """#include <iostream>
using namespace std;
struct Stack{int a[100],top=-1;};
int main(){Stack s; s.a[++s.top]=10;}""",
                "example": "Push 10",
                "complexity": "O(1)"
            }
        ]
    },

    # ------------ QUEUE ------------
    "queue": {
        "title": "Queue",
        "description": "FIFO structure",
        "types": [
            {
                "name": "Simple Queue",
                "description": "Uses front/rear",
                "pseudocode": "Enqueue/Dequeue",
                "code": """#include <iostream>
using namespace std;
struct Q{int a[100],f=-1,r=-1;};
int main(){Q q;}""",
                "example": "Enqueue then dequeue",
                "complexity": "O(1)"
            }
        ]
    },

    # ------------ TREE ------------
    "tree": {
        "title": "Trees",
        "description": "Hierarchical nodes",
        "types": [
            {
                "name": "Binary Tree Inorder",
                "description": "LNR traversal",
                "pseudocode": "Visit left, root, right",
                "code": """#include <iostream>
using namespace std;
struct Node{int d; Node*l,*r; Node(int x):d(x),l(NULL),r(NULL){}};
int main(){Node*r=new Node(1);}""",
                "example": "2 1 3",
                "complexity": "O(n)"
            }
        ]
    },

    # ------------ HASHING ------------
    "hashing": {
        "title": "Hashing",
        "description": "Maps keys to buckets",
        "types": [
            {
                "name": "Chaining",
                "description": "List per bucket",
                "pseudocode": "key % size",
                "code": """#include <iostream>
using namespace std;
int main(){cout<<"Hashing";}""",
                "example": "Keys stored in buckets",
                "complexity": "O(1)"
            }
        ]
    },

    # ------------ SEARCHING ------------
    "searching": {
        "title": "Searching",
        "description": "Find elements",
        "types": [
            {
                "name": "Linear Search",
                "description": "Sequential search",
                "pseudocode": "Loop over array",
                "code": """#include <iostream>
using namespace std;
int main(){cout<<"Linear Search";}""",
                "example": "Finds element",
                "complexity": "O(n)"
            },
            {
                "name": "Binary Search",
                "description": "Half search",
                "pseudocode": "Divide into halves",
                "code": """#include <iostream>
using namespace std;
int main(){cout<<"Binary Search";}""",
                "example": "Faster search",
                "complexity": "O(log n)"
            }
        ]
    },

    # ===================== QUIZZES =====================
    "quizzes": {

        # ✅ ARRAYS
        "arrays": {
            "title": "Arrays Quiz",
            "subtopic": "arrays",
            "questions": [
                {"q": "What is the time complexity to access an element at index i in an array?", "options": {"A":"O(n)","B":"O(log n)","C":"O(1)","D":"O(n log n)"}, "answer": "C", "explanation": "Direct indexing provides O(1) access."},
                {"q": "Which operation is costly in a dynamic array (amortized analysis)?", "options": {"A":"Append","B":"Random access","C":"Resizing","D":"Indexing"}, "answer": "C", "explanation": "Resizing requires allocating new memory and copying elements."},
                {"q": "Which of these is NOT contiguous in memory?", "options": {"A":"C array","B":"std::vector internal buffer","C":"Linked list","D":"Static array"}, "answer": "C", "explanation": "Linked list nodes are not stored contiguously."},
                {"q": "What is the space complexity of storing n elements in a standard array?", "options": {"A":"O(1)","B":"O(log n)","C":"O(n)","D":"O(n^2)"}, "answer": "C", "explanation": "An array stores n elements, so O(n)."},
                {"q": "Which operation on an array of size n costs O(n) in the worst case?", "options": {"A":"Access by index","B":"Insert at end (no resize)","C":"Insert at beginning","D":"Read-only traversal"}, "answer": "C", "explanation": "Inserting at beginning requires shifting elements."},
                {"q": "Given arr = [1,2,3,4], what is arr[2] (0-based)?", "options": {"A":"1","B":"2","C":"3","D":"4"}, "answer": "C", "explanation": "0-based index 2 is the third element: 3."},
                {"q": "Which array operation benefits most from caching and locality?", "options": {"A":"Random insert","B":"Sequential traversal","C":"Delete arbitrary element","D":"Linked traversal"}, "answer": "B", "explanation": "Sequential traversal benefits from CPU cache locality."},
                {"q": "Which of these is a benefit of static arrays over dynamic arrays?", "options": {"A":"Resizable capacity","B":"Compile-time fixed size","C":"Automatic growth","D":"Amortized append cost"}, "answer": "B", "explanation": "Static arrays have compile-time fixed size."},
                {"q": "What is a jagged array?", "options": {"A":"Array with same length rows","B":"2D array with different row lengths","C":"Rotated array","D":"Sparse array"}, "answer": "B", "explanation": "Jagged arrays have rows of varying lengths."},
                {"q": "Which data structure is best when you need frequent inserts/deletes in the middle?", "options": {"A":"Array","B":"Linked list","C":"Static array","D":"Fixed-size buffer"}, "answer": "B", "explanation": "Linked lists support O(1) insert/delete given node pointer."}
            ]
        },

        # ✅ LINKED LIST
        "linkedlist": {
            "title": "Linked List Quiz",
            "subtopic": "linkedlist",
            "questions": [
                {"q": "In a singly linked list, to insert at beginning takes:", "options": {"A":"O(1)","B":"O(log n)","C":"O(n)","D":"O(n log n)"}, "answer": "A", "explanation": "Update head pointer + next."},
                {"q": "To find the middle element of a singly linked list in one pass, use:", "options": {"A":"Two pointers (slow/fast)","B":"Stack","C":"Binary search","D":"Hash table"}, "answer": "A", "explanation": "Slow/fast pointers let you find middle in O(n)."},
                {"q": "Which operation is expensive for singly linked list if you only have head?", "options": {"A":"Insert at head","B":"Delete head","C":"Insert at tail","D":"Traverse"}, "answer": "C", "explanation": "Without tail pointer, inserting at tail requires O(n)."},
                {"q": "What extra pointer does a doubly linked list have over singly linked?", "options": {"A":"next","B":"prev","C":"head","D":"tail"}, "answer": "B", "explanation": "Doubly linked lists have a prev pointer."},
                {"q": "Which is a use-case of linked list over arrays?", "options": {"A":"Random access","B":"Frequent middle insertions","C":"Small memory","D":"Cache-friendly traversal"}, "answer": "B", "explanation": "Linked lists excel at frequent insertions/deletions."},
                {"q": "How do you detect a loop in a linked list efficiently?", "options": {"A":"Mark visited nodes","B":"Floyd’s cycle-finding algorithm","C":"Sort list","D":"Reverse list"}, "answer": "B", "explanation": "Floyd’s algorithm detects cycles in O(n)."},
                {"q": "What is the space complexity overhead for a doubly linked list compared to singly?", "options": {"A":"No overhead","B":"O(1) extra per node","C":"O(n^2)","D":"O(log n)"}, "answer": "B", "explanation": "Each node stores an extra pointer (prev)."},
                {"q": "Which linked list operation is O(n) even with pointers to head and tail?", "options": {"A":"Insert at head","B":"Insert at tail","C":"Delete arbitrary node by value","D":"Access head value"}, "answer": "C", "explanation": "Searching requires O(n)."},
                {"q": "Which structure cannot be efficiently implemented using singly linked list?", "options": {"A":"Stack","B":"Queue","C":"Random access array","D":"Adjacency list"}, "answer": "C", "explanation": "Linked lists do not allow O(1) random access."},
                {"q": "Which linked list variant allows O(1) removal if node pointer given?", "options": {"A":"Singly","B":"Doubly linked list","C":"Array list","D":"Circular array"}, "answer": "B", "explanation": "Doubly linked list removes in O(1)."}
            ]
        },

        # ✅ STACK
        "stack": {
            "title": "Stack Quiz",
            "subtopic": "stack",
            "questions": [
                {"q": "Stack follows which order?", "options": {"A":"FIFO","B":"LIFO","C":"Random","D":"Priority"}, "answer": "B", "explanation": "Last In First Out."},
                {"q": "Which is a typical use of a stack?", "options": {"A":"Level-order traversal","B":"Function call recursion management","C":"Database indexing","D":"Hashing"}, "answer": "B", "explanation": "Stack is used for recursion."},
                {"q": "What happens when popping from an empty stack?", "options": {"A":"Underflow","B":"Overflow","C":"Success","D":"Pointer moves forward"}, "answer": "A", "explanation": "Stack underflow."},
                {"q": "Which operation is O(1)?", "options": {"A":"Push","B":"Sort","C":"Search arbitrary","D":"Insert at bottom"}, "answer": "A", "explanation": "Push is O(1)."},
                {"q": "Which DS converts infix to postfix?", "options": {"A":"Queue","B":"Stack","C":"Heap","D":"Graph"}, "answer": "B", "explanation": "Stack handles operators."},
                {"q": "Stack using array: push may be?", "options": {"A":"Always O(1)","B":"O(n) on resize","C":"O(log n)","D":"O(n^2)"}, "answer": "B", "explanation": "Resize causes O(n)."},
                {"q": "Which algorithm uses stack?", "options": {"A":"BFS","B":"DFS","C":"Dijkstra","D":"Kruskal"}, "answer": "B", "explanation": "DFS uses stack."},
                {"q": "Undo operation uses?", "options": {"A":"Queue","B":"Stack","C":"Tree","D":"Hash table"}, "answer": "B", "explanation": "LIFO behavior."},
                {"q": "Space complexity storing n items?", "options": {"A":"O(1)","B":"O(log n)","C":"O(n)","D":"O(n^2)"}, "answer": "C", "explanation": "Need n storage."},
                {"q": "Which is NOT a stack operation?", "options": {"A":"Push","B":"Pop","C":"Enqueue","D":"Peek"}, "answer": "C", "explanation": "Enqueue is queue operation."}
            ]
        },

        # ✅ QUEUE
        "queue": {
            "title": "Queue Quiz",
            "subtopic": "queue",
            "questions": [
                {"q": "Queue follows which order?", "options": {"A":"LIFO","B":"FIFO","C":"Priority","D":"Random"}, "answer": "B", "explanation": "FIFO."},
                {"q": "Which gives O(1) enqueue/dequeue?", "options": {"A":"Simple array","B":"Circular buffer","C":"LL without tail","D":"Binary tree"}, "answer": "B"},
                {"q": "Which algorithm uses queue?", "options": {"A":"DFS","B":"BFS","C":"QuickSort","D":"HeapSort"}, "answer": "B"},
                {"q": "When queue is full?", "options": {"A":"Underflow","B":"Overflow","C":"Success","D":"Deletes oldest"}, "answer": "B"},
                {"q": "Priority queue supports:", "options": {"A":"FIFO","B":"LIFO","C":"Priority based order","D":"Random"}, "answer": "C"},
                {"q": "Linked-list queue o(1)?", "options": {"A":"Enqueue","B":"Dequeue","C":"Both","D":"Neither"}, "answer": "C"},
                {"q": "No circular wrap dequeue?", "options": {"A":"O(1)","B":"O(n) shift","C":"O(log n)","D":"Impossible"}, "answer": "B"},
                {"q": "Real world queue?", "options": {"A":"Browser history","B":"Printer jobs","C":"Function stack","D":"Trie"}, "answer": "B"},
                {"q": "Deque allows?", "options": {"A":"Front only","B":"Back only","C":"Both","D":"Middle"}, "answer": "C"},
                {"q": "Space complexity?", "options": {"A":"O(1)","B":"O(n)","C":"O(log n)","D":"O(n^2)"}, "answer": "B"}
            ]
        },

        # ✅ TREE
        "tree": {
            "title": "Trees Quiz",
            "subtopic": "tree",
            "questions": [
                {"q": "Max children in a binary tree?", "options": {"A":"1","B":"2","C":"3","D":"Depends"}, "answer": "B"},
                {"q": "Inorder traversal of BST gives?", "options": {"A":"Preorder","B":"Postorder","C":"Sorted","D":"Random"}, "answer": "C"},
                {"q": "Height of single node?", "options": {"A":"0 or 1","B":"2","C":"n","D":"Undefined"}, "answer": "A"},
                {"q": "Which uses queue?", "options": {"A":"Inorder","B":"Preorder","C":"Level-order","D":"Postorder"}, "answer": "C"},
                {"q": "Balanced BST?", "options": {"A":"Linked list","B":"AVL","C":"Unbalanced BST","D":"Hash"}, "answer": "B"},
                {"q": "Search in balanced BST?", "options": {"A":"O(n)","B":"O(log n)","C":"O(1)","D":"O(n log n)"}, "answer": "B"},
                {"q": "Database indexing?", "options": {"A":"Binary tree","B":"Heap","C":"B-Tree/B+Tree","D":"Trie"}, "answer": "C"},
                {"q": "Full binary tree?", "options": {"A":"0 or 2 children","B":"1 child","C":"All leaves same depth","D":"None"}, "answer": "A"},
                {"q": "Leaf node?", "options": {"A":"Root","B":"No children","C":"One child","D":"Parent only"}, "answer": "B"},
                {"q": "Prefix search?", "options": {"A":"BST","B":"Heap","C":"Trie","D":"Graph"}, "answer": "C"}
            ]
        },

        # ✅ HASHING
        "hashing": {
            "title": "Hashing Quiz",
            "subtopic": "hashing",
            "questions": [
                {"q": "Avg lookup?", "options": {"A":"O(1)","B":"O(log n)","C":"O(n)","D":"O(n log n)"}, "answer": "A"},
                {"q": "Collision occurs when?", "options": {"A":"Same index","B":"Hash fails","C":"Table full","D":"All equal"}, "answer": "A"},
                {"q": "Which uses linked lists?", "options": {"A":"Open addressing","B":"Chaining","C":"Rehashing","D":"Linear"}, "answer": "B"},
                {"q": "Next slot sequential?", "options": {"A":"Quadratic","B":"Double hashing","C":"Linear probing","D":"Chaining"}, "answer": "C"},
                {"q": "Load factor?", "options": {"A":"n/m","B":"m/n","C":"n^2/m","D":"None"}, "answer": "A"},
                {"q": "Downside of open addressing?", "options": {"A":"Extra memory","B":"Clustering","C":"Linked list issues","D":"None"}, "answer": "B"},
                {"q": "Benefits from good hash?", "options": {"A":"BST","B":"Hash table","C":"Array","D":"Heap"}, "answer": "B"},
                {"q": "Load factor > 0.7?", "options": {"A":"Nothing","B":"Resize & rehash","C":"Delete","D":"Switch"}, "answer": "B"},
                {"q": "NOT a cryptographic hash?", "options": {"A":"Deterministic","B":"Collision resistant","C":"Reversible","D":"Avalanche effect"}, "answer": "C"},
                {"q": "Expected O(1)?", "options": {"A":"Insert","B":"Delete","C":"Lookup","D":"All"}, "answer": "D"}
            ]
        },

        # ✅ SEARCHING
        "searching": {
            "title": "Searching Quiz",
            "subtopic": "searching",
            "questions": [
                {"q": "Binary search requires?", "options": {"A":"Unsorted","B":"Sorted","C":"Linked","D":"Empty"}, "answer": "B"},
                {"q": "Worst-case binary search?", "options": {"A":"O(n)","B":"O(log n)","C":"O(1)","D":"O(n log n)"}, "answer": "B"},
                {"q": "Linear > Binary when?", "options": {"A":"Sorted","B":"Very small/unsorted","C":"Need log n","D":"None"}, "answer": "B"},
                {"q": "Fibonacci search uses?", "options": {"A":"Primes","B":"Powers of 2","C":"Fibonacci","D":"Factorial"}, "answer": "C"},
                {"q": "Avg complexity linear search?", "options": {"A":"O(1)","B":"O(n)","C":"O(log n)","D":"O(n^2)"}, "answer": "B"},
                {"q": "Disk data search?", "options": {"A":"Binary unsorted","B":"B-tree","C":"Linear","D":"Fibonacci"}, "answer": "B"},
                {"q": "Interpolation search best when?", "options": {"A":"Uniformly distributed","B":"Descending","C":"All equal","D":"Random"}, "answer": "A"},
                {"q": "Exponential search idea?", "options": {"A":"Double range then binary search","B":"Exponent function","C":"Sort then scan","D":"Use stack"}, "answer": "A"},
                {"q": "Fibonacci search complexity?", "options": {"A":"O(n)","B":"O(log n)","C":"O(1)","D":"O(n log n)"}, "answer": "B"},
                {"q": "Hash table average search?", "options": {"A":"O(n)","B":"O(1)","C":"O(log n)","D":"O(n log n)"}, "answer": "B"}
            ]
        },

        # ✅ SORTING
        "sorting": {
            "title": "Sorting Quiz",
            "subtopic": "sorting",
            "questions": [
                {"q": "Worst-case QuickSort?", "options": {"A":"O(n)","B":"O(n log n)","C":"O(n^2)","D":"O(log n)"}, "answer": "C"},
                {"q": "Which sort stable?", "options": {"A":"Quick","B":"Merge","C":"Heap","D":"Selection"}, "answer": "B"},
                {"q": "Best for nearly sorted?", "options": {"A":"Bubble","B":"Insertion","C":"Selection","D":"Heap"}, "answer": "B"},
                {"q": "Heap sort complexity?", "options": {"A":"O(n)","B":"O(n log n)","C":"O(n^2)","D":"O(log n)"}, "answer": "B"},
                {"q": "In-place but not stable?", "options": {"A":"Merge","B":"Bubble","C":"Quick","D":"Counting"}, "answer": "C"},
                {"q": "Counting sort best when?", "options": {"A":"Small range","B":"Floats","C":"Huge range","D":"Linked list"}, "answer": "A"},
                {"q": "Radix sort?", "options": {"A":"O(n d)","B":"O(n log n)","C":"O(d log n)","D":"O(n^2)"}, "answer": "A"},
                {"q": "Comparison guaranteed O(n log n)?", "options": {"A":"Quick","B":"Merge","C":"Heap","D":"Both B & C"}, "answer": "D"},
                {"q": "Selection sort swaps?", "options": {"A":"O(n^2)","B":"O(n)","C":"O(1)","D":"O(log n)"}, "answer": "B"},
                {"q": "Adaptive and stable?", "options": {"A":"Insertion","B":"Heap","C":"Quick","D":"Selection"}, "answer": "A"}
            ]
        }
    }
}

# ===================== ROUTES =====================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/topics')
def get_topics():
    return jsonify(dsa_data)

@app.route('/api/topic/<topic_name>')
def get_topic(topic_name):
    if topic_name in dsa_data and topic_name != "quizzes":
        return jsonify(dsa_data[topic_name])
    return jsonify({"error": "Topic not found"}), 404

@app.route('/api/quizzes')
def get_all_quizzes():
    return jsonify(dsa_data["quizzes"])

@app.route('/api/quiz/<subtopic>')
def get_quiz(subtopic):
    quizzes = dsa_data.get("quizzes", {})
    if subtopic in quizzes:
        return jsonify(quizzes[subtopic])
    return jsonify({"error": "Quiz not found"}), 404

# ===================== COMMENTS =====================

@app.route('/api/comments/<topic>', methods=['GET'])
def get_comments(topic):
    if topic not in comments_data:
        return jsonify({"error": "Topic not found"}), 404
    return jsonify(comments_data[topic])

@app.route('/api/comments/<topic>', methods=['POST'])
def add_comment(topic):
    if topic not in comments_data:
        return jsonify({"error": "Topic not found"}), 404

    data = request.json or {}
    name = data.get("name", "Anonymous").strip()
    text = data.get("text", "").strip()

    if text == "":
        return jsonify({"error": "Comment text required"}), 400

    new_comment = {
        "name": name,
        "text": text,
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    comments_data[topic].append(new_comment)
    return jsonify({"message": "Comment added", "comment": new_comment}), 201

# ===================== RUN =====================
if __name__ == '__main__':
    app.run(debug=True)
