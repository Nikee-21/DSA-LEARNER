from flask import Flask, render_template, jsonify

app = Flask(__name__)

# DSA Data
dsa_data = {
    "arrays": {
        "title": "Arrays",
        "description": "Sequential collection of elements stored in contiguous memory locations",
        "types": [
            {
                "name": "1D Array",
                "description": "Linear array with single dimension",
                "pseudocode": """Algorithm: Traverse 1D Array
Input: arr[], n (size)
Output: Print all elements

1. START
2. FOR i = 0 to n-1
3.   PRINT arr[i]
4. END FOR
5. STOP""",
                "code": """#include <iostream>
using namespace std;

int main() {
    // Declaration and Initialization
    int arr[5] = {10, 20, 30, 40, 50};
    int n = 5;
    
    // Traversal
    cout << "Array elements: ";
    for(int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    
    return 0;
}""",
                "example": "Input: arr[] = {10, 20, 30, 40, 50}\nOutput: 10 20 30 40 50",
                "complexity": "Time: O(n), Space: O(1)"
            },
            {
                "name": "2D Array",
                "description": "Matrix representation with rows and columns",
                "pseudocode": """Algorithm: Traverse 2D Array
Input: arr[][], rows, cols
Output: Print all elements

1. START
2. FOR i = 0 to rows-1
3.   FOR j = 0 to cols-1
4.     PRINT arr[i][j]
5.   END FOR
6. END FOR
7. STOP""",
                "code": """#include <iostream>
using namespace std;

int main() {
    // 2D Array Declaration
    int arr[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };
    
    // Matrix Traversal
    cout << "Matrix:\\n";
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
    
    return 0;
}""",
                "example": "Input:\n1 2 3\n4 5 6\n7 8 9\n\nOutput: Prints the matrix row by row",
                "complexity": "Time: O(n*m), Space: O(1)"
            }
        ]
    },
    "linkedlist": {
        "title": "Linked List",
        "description": "Linear data structure where elements are stored in nodes with pointers",
        "types": [
            {
                "name": "Singly Linked List",
                "description": "Each node points to the next node",
                "pseudocode": """Algorithm: Insert at Beginning
Input: head, data
Output: Updated linked list

1. START
2. CREATE newNode with data
3. newNode->next = head
4. head = newNode
5. STOP""",
                "code": """#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void insertAtBeginning(Node** head, int data) {
    Node* newNode = new Node();
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

void display(Node* head) {
    while(head != NULL) {
        cout << head->data << " -> ";
        head = head->next;
    }
    cout << "NULL" << endl;
}

int main() {
    Node* head = NULL;
    
    insertAtBeginning(&head, 30);
    insertAtBeginning(&head, 20);
    insertAtBeginning(&head, 10);
    
    display(head);
    
    return 0;
}""",
                "example": "Operations: Insert 30, 20, 10\nOutput: 10 -> 20 -> 30 -> NULL",
                "complexity": "Time: O(1) for insertion, Space: O(1)"
            }
        ]
    },
    "stack": {
        "title": "Stack",
        "description": "LIFO (Last In First Out) data structure",
        "types": [
            {
                "name": "Array Implementation",
                "description": "Stack using static array",
                "pseudocode": """Algorithm: Push Operation
Input: stack[], top, data
Output: Updated stack

1. START
2. IF top >= MAX-1
3.   PRINT "Stack Overflow"
4. ELSE
5.   top = top + 1
6.   stack[top] = data
7. STOP""",
                "code": """#include <iostream>
#define MAX 100
using namespace std;

class Stack {
    int top;
    int arr[MAX];
    
public:
    Stack() { top = -1; }
    
    bool push(int x) {
        if(top >= MAX-1) {
            cout << "Stack Overflow\\n";
            return false;
        }
        arr[++top] = x;
        return true;
    }
    
    int pop() {
        if(top < 0) {
            cout << "Stack Underflow\\n";
            return -1;
        }
        return arr[top--];
    }
};

int main() {
    Stack s;
    s.push(10);
    s.push(20);
    s.push(30);
    
    cout << "Top element: " << s.peek() << endl;
    cout << "Popped: " << s.pop() << endl;
    
    return 0;
}""",
                "example": "Push: 10, 20, 30\nPeek: 30\nPop: 30\nRemaining: 20, 10",
                "complexity": "Time: O(1), Space: O(n)"
            }
        ]
    },
    "queue": {
        "title": "Queue",
        "description": "FIFO (First In First Out) data structure",
        "types": [
            {
                "name": "Simple Queue",
                "description": "Basic queue with front and rear pointers",
                "pseudocode": """Algorithm: Enqueue
Input: queue[], rear, data
Output: Updated queue

1. START
2. IF rear >= MAX-1
3.   PRINT "Queue Full"
4. ELSE
5.   rear = rear + 1
6.   queue[rear] = data
7. STOP""",
                "code": """#include <iostream>
#define MAX 100
using namespace std;

class Queue {
    int front, rear;
    int arr[MAX];
    
public:
    Queue() { 
        front = -1; 
        rear = -1; 
    }
    
    bool enqueue(int x) {
        if(rear >= MAX-1) {
            cout << "Queue Full\\n";
            return false;
        }
        if(front == -1) front = 0;
        arr[++rear] = x;
        return true;
    }
    
    int dequeue() {
        if(front == -1 || front > rear) {
            cout << "Queue Empty\\n";
            return -1;
        }
        return arr[front++];
    }
};

int main() {
    Queue q;
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    
    cout << "Dequeued: " << q.dequeue() << endl;
    
    return 0;
}""",
                "example": "Enqueue: 10, 20, 30\nDequeue: 10\nDequeue: 20\nRemaining: 30",
                "complexity": "Time: O(1), Space: O(n)"
            }
        ]
    },
    "tree": {
        "title": "Trees",
        "description": "Hierarchical data structure with nodes connected by edges",
        "types": [
            {
                "name": "Binary Tree",
                "description": "Tree where each node has at most two children",
                "pseudocode": """Algorithm: Inorder Traversal
Input: root
Output: Inorder sequence

1. START
2. IF root is NULL
3.   RETURN
4. Inorder(root->left)
5. PRINT root->data
6. Inorder(root->right)
7. STOP""",
                "code": """#include <iostream>
using namespace std;

struct Node {
    int data;
    Node *left, *right;
    
    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

void inorder(Node* root) {
    if(root == NULL) return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

int main() {
    Node* root = new Node(1);
    root->left = new Node(2);
    root->right = new Node(3);
    root->left->left = new Node(4);
    root->left->right = new Node(5);
    
    cout << "Inorder: ";
    inorder(root);
    
    return 0;
}""",
                "example": "Tree:\n     1\n    / \\\n   2   3\n  / \\\n 4   5\n\nInorder: 4 2 5 1 3",
                "complexity": "Time: O(n), Space: O(h)"
            }
        ]
    }
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/topics')
def get_topics():
    return jsonify(dsa_data)

@app.route('/api/topic/<topic_name>')
def get_topic(topic_name):
    if topic_name in dsa_data:
        return jsonify(dsa_data[topic_name])
    return jsonify({"error": "Topic not found"}), 404

if __name__ == '__main__':
    app.run(debug=True)