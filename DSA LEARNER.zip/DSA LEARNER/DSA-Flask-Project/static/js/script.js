let dsaTopics = {};
let currentTopic = null;

// Icon mapping
const iconMap = {
    'Arrays': '📊',
    'Linked List': '🔗',
    'Stack': '📚',
    'Queue': '📦',
    'Trees': '🌳'
};

// Load topics on page load
document.addEventListener('DOMContentLoaded', async () => {
    await loadTopics();
    setupEventListeners();
});

// Fetch topics from Flask API
async function loadTopics() {
    try {
        const response = await fetch('/api/topics');
        dsaTopics = await response.json();
        displayTopics();
    } catch (error) {
        console.error('Error loading topics:', error);
    }
}

// Display topics on home page
function displayTopics() {
    const grid = document.getElementById('topicsGrid');
    grid.innerHTML = '';

    Object.keys(dsaTopics).forEach(topicKey => {
        const topic = dsaTopics[topicKey];
        const card = createTopicCard(topicKey, topic);
        grid.appendChild(card);
    });
}

// Create topic card
function createTopicCard(topicKey, topic) {
    const card = document.createElement('div');
    card.className = 'topic-card';
    card.onclick = () => showTopicDetail(topicKey);

    card.innerHTML = `
        <div class="topic-card-header">
            <div class="topic-icon">${iconMap[topic.title] || '📖'}</div>
            <h3>${topic.title}</h3>
        </div>
        <p>${topic.description}</p>
        <div class="learn-more">
            Learn More →
        </div>
    `;

    return card;
}

// Show topic detail page
function showTopicDetail(topicKey) {
    currentTopic = topicKey;
    const topic = dsaTopics[topicKey];

    // Update header
    const header = document.getElementById('topicHeader');
    header.innerHTML = `
        <div class="topic-header-content">
            <div class="topic-header-icon">${iconMap[topic.title] || '📖'}</div>
            <div>
                <h1>${topic.title}</h1>
                <p>${topic.description}</p>
            </div>
        </div>
    `;

    // Display subtopics
    displaySubtopics(topic.types);

    // Switch pages
    document.getElementById('homePage').classList.remove('active');
    document.getElementById('detailPage').classList.add('active');
}

// Display subtopics
function displaySubtopics(types) {
    const container = document.getElementById('subtopicsContainer');
    container.innerHTML = '';

    types.forEach((type, index) => {
        const card = createSubtopicCard(type, index);
        container.appendChild(card);
    });
}

// Create subtopic card
function createSubtopicCard(type, index) {
    const card = document.createElement('div');
    card.className = 'subtopic-card';
    card.id = `subtopic-${index}`;

    card.innerHTML = `
        <div class="subtopic-header">
            <h3>${type.name}</h3>
            <p>${type.description}</p>
        </div>
        <div class="subtopic-content">
            <div class="content-section pseudocode-section">
                <h4>📖 Pseudocode</h4>
                <pre>${escapeHtml(type.pseudocode)}</pre>
            </div>

            <div class="content-section code-section">
                <h4>💻 C++ Implementation</h4>
                <pre>${escapeHtml(type.code)}</pre>
            </div>

            <div class="content-section example-section">
                <h4>✅ Example</h4>
                <pre>${escapeHtml(type.example)}</pre>
            </div>

            <div class="content-section complexity-section">
                <h4>⚡ Complexity Analysis</h4>
                <p>${type.complexity}</p>
            </div>
        </div>
    `;

    card.querySelector('.subtopic-header').addEventListener('click', () => {
        card.classList.toggle('active');
    });

    return card;
}

// Setup event listeners
function setupEventListeners() {
    document.getElementById('backButton').addEventListener('click', () => {
        document.getElementById('detailPage').classList.remove('active');
        document.getElementById('homePage').classList.add('active');
    });
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}